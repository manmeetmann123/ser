
class Player
    attr_accessor :colour
  
    def initialize
        @colour = nil
    end
  
end
  